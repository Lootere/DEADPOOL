"""Feature 46 post-implementation bug-fix tests.

Covers the three reported bugs:
1. missing IMDb metadata / poster in notifications
2. missing series metadata
3. missing `/notification` admin command registration

All tests are offline: provider HTTP is patched with deterministic doubles.
"""
import asyncio
import base64
import importlib.util
import io
import os
import sys
import types
import unittest
import urllib.error
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))

UTILS_DIR = ROOT / "Lootere" / "utils"


def _load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


_lootere_pkg = sys.modules.setdefault("Lootere", types.ModuleType("Lootere"))
_lootere_pkg.__path__ = [str(ROOT / "Lootere")]
_utils_pkg = sys.modules.setdefault("Lootere.utils", types.ModuleType("Lootere.utils"))
_utils_pkg.__path__ = [str(UTILS_DIR)]

if "Lootere.utils.smart_search_engine" not in sys.modules:
    _load_module("Lootere.utils.smart_search_engine", UTILS_DIR / "smart_search_engine.py")

engine = _load_module(
    "Lootere.utils.notification_engine", UTILS_DIR / "notification_engine.py"
)
imdb = _load_module("Lootere.utils.imdb_metadata", UTILS_DIR / "imdb_metadata.py")
setattr(_utils_pkg, "notification_engine", engine)
setattr(_utils_pkg, "imdb_metadata", imdb)

SCRIPT = _load_module("Script", ROOT / "Script.py")
script = SCRIPT.script

GB = 1024 ** 3


class FakeMedia:
    def __init__(self, file_name, file_size=1 * GB, file_id="file-1", unique="unique-1"):
        self.file_name = file_name
        self.file_size = file_size
        self.file_id = file_id
        self.file_unique_id = unique


FULL_MOVIE_NODE = {
    "id": "tt1932660",
    "titleText": {"text": "Kongsi"},
    "originalTitleText": {"text": "Kongsi"},
    "releaseYear": {"year": 2011},
    "ratingsSummary": {"aggregateRating": 5.2, "voteCount": 153},
    "genres": {"genres": [{"text": "Action"}, {"text": "Comedy"}]},
    "plot": {"plotText": {"plainText": "A murderer is sent to curb secret societies in Kuala Lumpur."}},
    "runtime": {"seconds": 5400},
    "spokenLanguages": {"spokenLanguages": [{"text": "Malay"}]},
    "primaryImage": {"url": "https://m.media-amazon.com/images/M/poster.jpg"},
    "titleType": {"id": "movie", "text": "Movie"},
}

FULL_SERIES_NODE = {
    "id": "tt29625288",
    "titleText": {"text": "Akka"},
    "originalTitleText": {"text": "Akka"},
    "releaseYear": {"year": 2026},
    "ratingsSummary": {"aggregateRating": 7.4},
    "genres": {"genres": [{"text": "Crime"}, {"text": "Drama"}]},
    "plot": {"plotText": {"plainText": "A woman fights a powerful crime network."}},
    "runtime": {"seconds": 2700},
    "spokenLanguages": {"spokenLanguages": [{"text": "Hindi"}]},
    "primaryImage": {"url": "https://m.media-amazon.com/images/M/akka.jpg"},
    "titleType": {"id": "tvSeries", "text": "TV Series"},
}


def movie_event(file_name="Kongsi.2011.720p.Hindi.mkv", unique="movie-1"):
    return engine.build_event(FakeMedia(file_name, unique=unique))


# ---------------------------------------------------------------------------
# In-memory Mongo doubles
# ---------------------------------------------------------------------------
class _Result:
    def __init__(self, upserted_id=None, modified_count=0):
        self.upserted_id = upserted_id
        self.modified_count = modified_count


def _match(doc, query):
    for key, expected in (query or {}).items():
        actual = doc.get(key)
        if isinstance(expected, dict):
            for op, value in expected.items():
                if op == "$in" and actual not in value:
                    return False
                if op == "$ne" and actual == value:
                    return False
                if op == "$lte" and not (actual is not None and actual <= value):
                    return False
                if op == "$lt" and not (actual is not None and actual < value):
                    return False
                if op == "$gte" and not (actual is not None and actual >= value):
                    return False
                if op == "$gt" and not (actual is not None and actual > value):
                    return False
        elif actual != expected:
            return False
    return True


class _Cursor:
    def __init__(self, docs, sort_spec=None):
        self._docs = [dict(doc) for doc in docs]
        if sort_spec:
            for key, direction in reversed(list(sort_spec)):
                self._docs.sort(
                    key=lambda doc: (doc.get(key) is None, doc.get(key)),
                    reverse=(direction < 0),
                )

    def limit(self, value):
        self._docs = self._docs[:value]
        return self

    def sort(self, spec, direction=None):
        if direction is not None:
            spec = [(spec, direction)]
        self._docs = _Cursor(self._docs, spec).to_list()
        return self

    def to_list(self):
        return self._docs

    def __aiter__(self):
        self._iter = iter([dict(doc) for doc in self._docs])
        return self

    async def __anext__(self):
        try:
            return next(self._iter)
        except StopIteration:
            raise StopAsyncIteration


class FakeCollection:
    def __init__(self):
        self.docs = []
        self._counter = 0

    def _next_id(self):
        self._counter += 1
        return self._counter

    async def create_index(self, *args, **kwargs):
        return "idx"

    async def insert_one(self, doc):
        stored = dict(doc)
        stored.setdefault("_id", self._next_id())
        self.docs.append(stored)
        return _Result(upserted_id=stored["_id"])

    async def count_documents(self, query):
        return sum(1 for doc in self.docs if _match(doc, query))

    def find(self, query=None, projection=None):
        return _Cursor([doc for doc in self.docs if _match(doc, query or {})])

    async def find_one(self, query, sort=None):
        docs = _Cursor([doc for doc in self.docs if _match(doc, query)], sort).to_list()
        return dict(docs[0]) if docs else None

    def _apply(self, doc, update):
        for key, value in (update.get("$set") or {}).items():
            doc[key] = value
        for key, value in (update.get("$setOnInsert") or {}).items():
            doc.setdefault(key, value)

    async def update_one(self, query, update, upsert=False):
        for doc in self.docs:
            if _match(doc, query):
                self._apply(doc, update)
                return _Result(modified_count=1)
        if upsert:
            new_doc = {k: v for k, v in (query or {}).items() if not isinstance(v, dict)}
            new_doc["_id"] = self._next_id()
            self._apply(new_doc, update)
            self.docs.append(new_doc)
            return _Result(upserted_id=new_doc["_id"])
        return _Result()

    async def update_many(self, query, update):
        count = 0
        for doc in self.docs:
            if _match(doc, query):
                self._apply(doc, update)
                count += 1
        return _Result(modified_count=count)

    async def find_one_and_update(self, query, update, sort=None, return_document=True):
        docs = _Cursor([doc for doc in self.docs if _match(doc, query)], sort).to_list()
        if not docs:
            return None
        target = next(doc for doc in self.docs if doc["_id"] == docs[0]["_id"])
        self._apply(target, update)
        return dict(target)


class FakeDatabase(dict):
    def __init__(self):
        super().__init__()
        for name in (
            engine.EVENTS_COLLECTION,
            engine.DELIVERIES_COLLECTION,
            engine.BATCHES_COLLECTION,
            engine.METADATA_COLLECTION,
            engine.DIGESTS_COLLECTION,
            engine.AUDIT_COLLECTION,
            "settings",
        ):
            self[name] = FakeCollection()


class FakeMessage:
    def __init__(self, chat_id, text):
        self.chat_id = chat_id
        self.text = text
        self.replies = []
        self.sent = []
        self.message_id = 1

    async def reply_text(self, text, **kwargs):
        self.replies.append((text, kwargs))
        return self

    async def edit_text(self, text, **kwargs):
        self.replies.append((text, kwargs))
        return self

    async def delete(self):
        return True


class FakeUser:
    def __init__(self, user_id):
        self.id = user_id


class FakeQuery:
    def __init__(self, user_id, data="autonotif#stats"):
        self.from_user = FakeUser(user_id)
        self.data = data
        self.answers = []
        self.message = FakeMessage(user_id, "panel")

    async def answer(self, text="", show_alert=False):
        self.answers.append((text, show_alert))
        return True


class FakeBot:
    def __init__(self, failing_messages=(), failing_photos=()):
        self.failing_messages = {str(chat) for chat in failing_messages}
        self.failing_photos = {str(chat) for chat in failing_photos}
        self.messages = []
        self.photos = []
        self.username = "testbot"

    async def send_message(self, chat_id, text, **kwargs):
        if str(chat_id) in self.failing_messages:
            raise RuntimeError("chat unavailable")
        self.messages.append({"chat_id": str(chat_id), "text": text, **kwargs})

        class Message:
            id = len(self.messages)

        return Message()

    async def send_photo(self, chat_id, photo, caption, **kwargs):
        if str(chat_id) in self.failing_photos:
            raise RuntimeError("photo rejected")
        self.photos.append({"chat_id": str(chat_id), "photo": photo, "caption": caption, **kwargs})

        class Message:
            id = len(self.photos)

        return Message()


class FakeClient:
    def __init__(self):
        self.command_calls = []

    async def set_bot_commands(self, commands, scope=None):
        self.command_calls.append((list(commands), scope))


# ---------------------------------------------------------------------------
# Metadata provider tests
# ---------------------------------------------------------------------------
class MetadataProviderTests(unittest.TestCase):
    def test_complete_movie_metadata_is_mapped(self):
        metadata = imdb.metadata_from_node(FULL_MOVIE_NODE)
        self.assertEqual(metadata["title"], "Kongsi")
        self.assertEqual(metadata["year"], "2011")
        self.assertEqual(metadata["rating"], "5.2")
        self.assertEqual(metadata["genres"], "Action, Comedy")
        self.assertEqual(metadata["imdb_id"], "tt1932660")
        self.assertEqual(metadata["languages"], "Malay")
        self.assertEqual(metadata["runtime"], "1h 30m")
        self.assertEqual(metadata["poster"], "https://m.media-amazon.com/images/M/poster.jpg")
        self.assertIn("secret societies", metadata["plot"])

    def test_movie_caption_shows_every_available_field(self):
        event = movie_event()
        metadata = imdb.metadata_from_node(FULL_MOVIE_NODE)
        caption = engine.build_movie_caption(event, metadata, engine.DEFAULT_SETTINGS)
        for expected in (
            "NEW MOVIE UPLOADED",
            "Kongsi (2011)",
            "⭐ IMDb: 5.2/10",
            "🆔 IMDb: tt1932660",
            "🎬 Genre: Action, Comedy",
            "🌐 Language: Hindi",  # event language is kept when present
            "🎞️ Quality: 720p",
            "⏱️ Runtime: 1h 30m",
            "📝 Description:",
            "secret societies",
        ):
            self.assertIn(expected, caption)
        for forbidden in ("None", "N/A", "null"):
            self.assertNotIn(forbidden, caption)

    def test_payload_carries_official_poster(self):
        event = movie_event()
        metadata = imdb.metadata_from_node(FULL_MOVIE_NODE)
        payload = engine.build_payload(
            "owner", "movie", [event], metadata, engine.DEFAULT_SETTINGS
        )
        self.assertEqual(payload["poster"], metadata["poster"])
        self.assertEqual(payload["button_text"], "GET NOW")

    def test_movie_with_no_poster_stays_text_safe(self):
        metadata = imdb.metadata_from_node(FULL_MOVIE_NODE)
        metadata.pop("poster")
        payload = engine.build_payload(
            "owner", "movie", [movie_event()], metadata, engine.DEFAULT_SETTINGS
        )
        self.assertEqual(payload["poster"], "")
        self.assertIn("Kongsi", payload["captions"][0])

    def test_no_imdb_match_returns_reason(self):
        original = imdb.search_titles
        imdb.search_titles = lambda query, timeout=12: []
        try:
            metadata, reason = imdb.lookup_sync("Unknown Film", 1999, "movie")
        finally:
            imdb.search_titles = original
        self.assertEqual(metadata, {})
        self.assertEqual(reason, "no search results")

    def test_ambiguous_movie_title_is_rejected(self):
        candidates = [
            {
                "imdb_id": "tt0000001",
                "title": "Kongsi",
                "year": 2011,
                "kind": "feature",
                "rank": 100,
            },
            {
                "imdb_id": "tt0000002",
                "title": "Kongsi",
                "year": 2011,
                "kind": "feature",
                "rank": 100,
            },
        ]
        match, reason = imdb.select_best_match(candidates, "Kongsi", 2011, "movie")
        self.assertIsNone(match)
        self.assertEqual(reason, "ambiguous match")

    def test_series_match_prefers_series_and_builds_caption(self):
        candidates = [
            {"imdb_id": "tt9990000", "title": "Akka", "year": 2026, "kind": "feature", "rank": 50},
            {
                "imdb_id": "tt29625288",
                "title": "Akka 2026",
                "year": 2026,
                "kind": "tv series",
                "rank": 900,
            },
        ]
        match, reason = imdb.select_best_match(candidates, "Akka", 2026, "series")
        self.assertEqual(reason, "")
        self.assertEqual(match["imdb_id"], "tt29625288")

        events = [
            engine.build_event(
                FakeMedia(
                    f"Akka.2026.S01E{episode:02d}.1080p.Hindi.mkv", unique=f"ep-{episode}"
                )
            )
            for episode in range(1, 4)
        ]
        metadata = imdb.metadata_from_node(FULL_SERIES_NODE)
        captions = engine.build_series_captions(events, metadata, engine.DEFAULT_SETTINGS)
        text = "\n".join(captions)
        for expected in (
            "NEW SERIES EPISODES ADDED",
            "Akka (2026) — Season 1",
            "⭐ IMDb: 7.4/10",
            "🎬 Genre: Crime, Drama",
            "📝 Description:",
            "Total New Episodes: 3",
        ):
            self.assertIn(expected, text)
        for episode in range(1, 4):
            self.assertIn(f"E{episode:02d} S01", text)

    def test_provider_timeout_is_reported(self):
        original = imdb._http_json

        def failing(*args, **kwargs):
            raise imdb.MetadataLookupError("provider unreachable: timed out")

        imdb._http_json = failing
        try:
            metadata, reason = imdb.lookup_sync("Kongsi", 2011, "movie")
        finally:
            imdb._http_json = original
        self.assertEqual(metadata, {})
        self.assertIn("timed out", reason)

    def test_invalid_poster_url_is_rejected(self):
        usable, reason = imdb._poster_check_sync("not-a-url")
        self.assertFalse(usable)
        self.assertIn("invalid poster URL", reason)

        original = imdb.urllib.request.urlopen

        def missing(*args, **kwargs):
            raise urllib.error.HTTPError(
                "https://example.com/missing.jpg", 404, "Not Found", {}, None
            )

        imdb.urllib.request.urlopen = missing
        try:
            usable, reason = imdb._poster_check_sync("https://example.com/missing.jpg")
        finally:
            imdb.urllib.request.urlopen = original
        self.assertFalse(usable)
        self.assertIn("404", reason)

    def test_valid_poster_is_accepted(self):
        class _Headers:
            @staticmethod
            def get_content_type():
                return "image/jpeg"

            @staticmethod
            def get(key, default=None):
                return "image/jpeg" if key == "Content-Type" else default

        class Response:
            headers = _Headers()

            def __enter__(self):
                return self

            def __exit__(self, *args):
                return False

        original = imdb.urllib.request.urlopen
        imdb.urllib.request.urlopen = lambda *a, **k: Response()
        try:
            usable, reason = imdb._poster_check_sync("https://example.com/poster.jpg")
        finally:
            imdb.urllib.request.urlopen = original
        self.assertTrue(usable)
        self.assertEqual(reason, "")


class MetadataCacheTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = FakeDatabase()
        engine.set_database(self.db)
        self.settings = dict(engine.DEFAULT_SETTINGS)

    async def asyncTearDown(self):
        engine.set_database(None)

    async def test_cache_miss_then_hit(self):
        calls = []

        async def fake_cinemagoer(event, settings):
            calls.append("cinemagoer")
            return {}, "cinemagoer returned no metadata"

        original_cinemagoer = engine._lookup_cinemagoer
        original_public = engine._lookup_public_imdb
        engine._lookup_cinemagoer = fake_cinemagoer

        async def fake_public(event, settings):
            calls.append("imdb")
            return imdb.metadata_from_node(FULL_MOVIE_NODE), ""

        engine._lookup_public_imdb = fake_public
        try:
            event = movie_event()
            metadata = await engine.resolve_metadata(event, self.settings)
            self.assertEqual(metadata["imdb_id"], "tt1932660")
            self.assertEqual(event["metadata_source"], "imdb")
            cached = self.db[engine.METADATA_COLLECTION].docs
            self.assertEqual(len(cached), 1)
            self.assertEqual(cached[0]["source"], "imdb")

            second_event = movie_event(unique="movie-2")
            second = await engine.resolve_metadata(second_event, self.settings)
            self.assertEqual(second["rating"], "5.2")
            # Cache hits keep the original provider name as the metadata source.
            self.assertEqual(second_event["metadata_source"], "imdb")
            self.assertEqual(calls.count("imdb"), 1)
        finally:
            engine._lookup_cinemagoer = original_cinemagoer
            engine._lookup_public_imdb = original_public

    async def test_failure_reason_is_recorded_on_event(self):
        original_cinemagoer = engine._lookup_cinemagoer
        original_public = engine._lookup_public_imdb

        async def fake_cinemagoer(event, settings):
            return {}, "cinemagoer returned no metadata"

        async def fake_public(event, settings):
            return {}, "no search results"

        engine._lookup_cinemagoer = fake_cinemagoer
        engine._lookup_public_imdb = fake_public
        try:
            event = movie_event()
            metadata = await engine.resolve_metadata(event, self.settings)
        finally:
            engine._lookup_cinemagoer = original_cinemagoer
            engine._lookup_public_imdb = original_public

        self.assertEqual(metadata, {})
        self.assertIn("cinemagoer returned no metadata", event["metadata_error"])
        self.assertIn("no search results", event["metadata_error"])

    async def test_override_still_wins_over_providers(self):
        self.assertTrue(
            await engine.override_metadata(
                "Kongsi",
                year="2011",
                rating="9.9",
                poster="https://example.com/manual.jpg",
                plot="Admin corrected plot.",
            )
        )
        original_cinemagoer = engine._lookup_cinemagoer

        async def exploding(event, settings):
            raise AssertionError("provider must not run for an override")

        engine._lookup_cinemagoer = exploding
        try:
            metadata = await engine.resolve_metadata(movie_event(), self.settings)
        finally:
            engine._lookup_cinemagoer = original_cinemagoer
        self.assertEqual(metadata["rating"], "9.9")
        self.assertEqual(metadata["poster"], "https://example.com/manual.jpg")


# ---------------------------------------------------------------------------
# Admin command tests
# ---------------------------------------------------------------------------
def _load_admin_plugin():
    if "info" not in sys.modules:
        info_stub = types.ModuleType("info")
        info_stub.ADMINS = [111, 222]
        sys.modules["info"] = info_stub
    name = "plugins.auto_notifications"
    if name in sys.modules:
        return sys.modules[name]
    return _load_module(name, ROOT / "plugins" / "auto_notifications.py")


class AdminCommandTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = FakeDatabase()
        engine.set_database(self.db)
        self.plugin = _load_admin_plugin()

    async def asyncTearDown(self):
        engine.set_database(None)

    def test_notification_is_a_registered_manager_command(self):
        self.assertIn("notification", self.plugin.MANAGER_COMMANDS)
        self.assertIn("autonotif", self.plugin.MANAGER_COMMANDS)
        self.assertTrue(callable(self.plugin.auto_notification_manager))
        self.assertTrue(callable(self.plugin.auto_notification_callback))

    def test_notification_is_in_admin_help_text(self):
        self.assertIn("/notification", script.ADMIC_TXT)

    async def test_command_registered_in_telegram_admin_menu(self):
        client = FakeClient()
        registered = await self.plugin.register_admin_commands(client)
        self.assertEqual(registered, 2)
        self.assertEqual(len(client.command_calls), 2)
        for commands, scope in client.command_calls:
            names = [command.command for command in commands]
            self.assertIn("notification", names)
            self.assertEqual(scope.type, "chat")
            self.assertIn(scope.chat_id, {111, 222})

    async def test_registration_is_restart_safe(self):
        client = FakeClient()
        await self.plugin.register_admin_commands(client)
        await self.plugin.register_admin_commands(client)
        self.assertEqual(len(client.command_calls), 4)

    def test_bot_startup_registers_admin_menu(self):
        source = (ROOT / "bot.py").read_text(encoding="utf-8")
        self.assertIn("register_admin_commands", source)
        self.assertIn("plugins.auto_notifications", source)

    async def test_admin_can_open_manager(self):
        message = FakeMessage(111, "/notification")
        message.from_user = FakeUser(111)
        await self.plugin.auto_notification_manager(None, message)
        self.assertTrue(message.replies)
        self.assertIn("AUTO NOTIFICATION MANAGER", message.replies[0][0])

    async def test_unauthorized_user_is_denied(self):
        message = FakeMessage(999, "/notification")
        message.from_user = FakeUser(999)
        await self.plugin.auto_notification_manager(None, message)
        self.assertIn("restricted", message.replies[0][0])

    async def test_unauthorized_callback_is_denied(self):
        query = FakeQuery(999)
        await self.plugin.auto_notification_callback(None, query)
        self.assertEqual(query.answers[0][0], "Admins only.")
        self.assertTrue(query.answers[0][1])
        self.assertEqual(query.message.replies, [])

    def test_existing_admin_commands_are_not_removed(self):
        # The plugin must stay additive: no other plugin file was rewritten.
        plugin_files = {path.name for path in (ROOT / "plugins").glob("*.py")}
        for expected in (
            "commands.py",
            "broadcast.py",
            "channel.py",
            "index.py",
            "pm_filter.py",
        ):
            self.assertIn(expected, plugin_files)
        source = (ROOT / "plugins" / "auto_notifications.py").read_text(encoding="utf-8")
        self.assertIn("auto_notifications_set", source)
        self.assertIn("auto_notifications_override", source)


# ---------------------------------------------------------------------------
# Delivery regression tests
# ---------------------------------------------------------------------------
class DeliveryTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = FakeDatabase()
        self.previous_db = engine._db_handle
        self.previous_get_settings = engine.get_settings
        self.previous_resolve = engine.resolve_metadata
        self.previous_poster_usable = engine._poster_usable
        self.previous_poster_image = engine._poster_image
        engine.set_database(self.db)
        self.settings = dict(engine.DEFAULT_SETTINGS)
        self.settings.update(
            {
                "enabled": True,
                "channel_id": "-100111",
                "channel_enabled": True,
                "group_id": "-100222",
                "group_enabled": True,
                "button_url": "https://t.me/examplegroup",
                "batch_window_seconds": 0,
            }
        )

        async def fake_get_settings(force=False):
            return dict(self.settings)

        async def fake_resolve(event, settings):
            event["metadata_source"] = "test"
            return imdb.metadata_from_node(FULL_MOVIE_NODE)

        async def poster_usable(poster):
            return True

        async def poster_image(poster):
            # Offline by default: the bytes retry path is tested explicitly.
            return b"", "", "test offline"

        engine.get_settings = fake_get_settings
        engine.resolve_metadata = fake_resolve
        engine._poster_usable = poster_usable
        engine._poster_image = poster_image

    async def asyncTearDown(self):
        engine.set_database(self.previous_db)
        engine.get_settings = self.previous_get_settings
        engine.resolve_metadata = self.previous_resolve
        engine._poster_usable = self.previous_poster_usable
        engine._poster_image = self.previous_poster_image

    async def _queue_movie(self, unique="movie-1"):
        await engine.record_upload_event(
            FakeMedia("Kongsi.2011.720p.Hindi.mkv", unique=unique)
        )
        await engine.process_once(FakeBot())

    async def test_photo_caption_and_button_reach_channel_and_group(self):
        bot = FakeBot()
        await engine.record_upload_event(FakeMedia("Kongsi.2011.720p.Hindi.mkv"))
        await engine.process_once(bot)
        self.assertEqual(len(bot.photos), 2)
        chat_ids = {photo["chat_id"] for photo in bot.photos}
        self.assertEqual(chat_ids, {"-100111", "-100222"})
        for photo in bot.photos:
            self.assertEqual(photo["photo"], FULL_MOVIE_NODE["primaryImage"]["url"])
            self.assertIn("Kongsi (2011)", photo["caption"])
            self.assertIsNotNone(photo["reply_markup"])
            button = photo["reply_markup"].inline_keyboard[0][0]
            self.assertEqual(button.text, "GET NOW")
            self.assertEqual(button.url, "https://t.me/examplegroup")

    async def test_channel_failure_does_not_block_group(self):
        bot = FakeBot(failing_photos={"-100111"})
        await engine.record_upload_event(FakeMedia("Kongsi.2011.720p.Hindi.mkv"))
        await engine.process_once(bot)
        # Channel photo failed, so it falls back to text; group must still be sent.
        self.assertIn("-100222", {photo["chat_id"] for photo in bot.photos})
        deliveries = self.db[engine.DELIVERIES_COLLECTION].docs
        group = [doc for doc in deliveries if doc["destination_type"] == "group"]
        self.assertEqual(group[0]["status"], "SENT")

    async def test_group_failure_does_not_block_channel(self):
        original_get_settings = engine.get_settings

        async def settings_with_broken_group(force=False):
            broken = dict(self.settings)
            broken["group_id"] = "-100999"
            return broken

        engine.get_settings = settings_with_broken_group
        try:
            bot = FakeBot(failing_messages={"-100999"})
            await engine.record_upload_event(FakeMedia("Kongsi.2011.720p.Hindi.mkv"))
            await engine.process_once(bot)
        finally:
            engine.get_settings = original_get_settings
        self.assertIn("-100111", {photo["chat_id"] for photo in bot.photos})
        deliveries = self.db[engine.DELIVERIES_COLLECTION].docs
        channel = [doc for doc in deliveries if doc["destination_type"] == "channel"]
        self.assertEqual(channel[0]["status"], "SENT")

    async def test_invalid_poster_falls_back_to_text(self):
        original_resolve = engine.resolve_metadata

        async def metadata_without_poster(event, settings):
            data = imdb.metadata_from_node(FULL_MOVIE_NODE)
            data["poster"] = "https://example.com/broken.jpg"
            return data

        async def unusable(poster):
            return False

        engine.resolve_metadata = metadata_without_poster
        engine._poster_usable = unusable
        try:
            bot = FakeBot()
            await engine.record_upload_event(FakeMedia("Kongsi.2011.720p.Hindi.mkv"))
            await engine.process_once(bot)
        finally:
            engine.resolve_metadata = original_resolve
        self.assertEqual(bot.photos, [])
        self.assertEqual(len(bot.messages), 2)
        self.assertIn("Kongsi (2011)", bot.messages[0]["text"])

    async def test_long_caption_is_sent_as_text_not_failed(self):
        bot = FakeBot()
        delivery = {
            "chat_id": "-100111",
            "caption": "x" * 1200,
            "poster": FULL_MOVIE_NODE["primaryImage"]["url"],
            "button_text": "GET NOW",
            "button_url": "https://t.me/examplegroup",
        }
        await engine._deliver(bot, delivery)
        self.assertEqual(bot.photos, [])
        self.assertEqual(len(bot.messages), 1)
        self.assertEqual(len(bot.messages[0]["text"]), 1200)

    async def test_send_photo_permanent_error_falls_back_to_text(self):
        class RejectingPhotoBot(FakeBot):
            async def send_photo(self, chat_id, photo, caption, **kwargs):
                raise RuntimeError("PHOTO_INVALID_DIMENSIONS")

        bot = RejectingPhotoBot()
        await engine.record_upload_event(FakeMedia("Kongsi.2011.720p.Hindi.mkv"))
        await engine.process_once(bot)
        self.assertEqual(bot.photos, [])
        self.assertEqual(len(bot.messages), 2)

    async def test_no_duplicate_notifications(self):
        bot = FakeBot()
        await engine.record_upload_event(FakeMedia("Kongsi.2011.720p.Hindi.mkv"))
        await engine.process_once(bot)
        sent_after_first = len(bot.photos)
        await engine.process_once(bot)
        self.assertEqual(len(bot.photos), sent_after_first)

    async def test_weekly_digest_still_works(self):
        await engine.record_upload_event(FakeMedia("Kongsi.2011.720p.Hindi.mkv"))
        await engine.process_once(FakeBot())
        bot = FakeBot()
        digest_id = await engine.force_publish_weekly_digest(bot, admin_id=111)
        self.assertTrue(digest_id)
        await engine.process_deliveries(bot)
        self.assertTrue(bot.messages)
        self.assertIn("WEEKLY UPLOAD REPORT", bot.messages[0]["text"])
        self.assertEqual(len(self.db[engine.DIGESTS_COLLECTION].docs), 1)


# ---------------------------------------------------------------------------
# Poster-only regression tests
# ---------------------------------------------------------------------------
PNG_BYTES = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="
)
POSTER_URL = "https://m.media-amazon.com/images/M/poster.jpg"


class StrictPhotoBot:
    """Mirrors pyrogram's send_photo signature: no **kwargs, no
    disable_web_page_preview. The original bug was a TypeError raised here."""

    def __init__(self, reject_urls=False):
        self.photos = []
        self.messages = []
        self.reject_urls = reject_urls
        self.username = "testbot"

    async def send_photo(
        self,
        chat_id,
        photo,
        caption="",
        parse_mode=None,
        caption_entities=None,
        has_spoiler=None,
        disable_notification=None,
        message_thread_id=None,
        reply_to_message_id=None,
        reply_markup=None,
        progress=None,
        progress_args=(),
    ):
        if self.reject_urls and isinstance(photo, str):
            raise ValueError("Telegram could not fetch the photo URL")
        self.photos.append(
            {
                "chat_id": str(chat_id),
                "photo": photo,
                "caption": caption,
                "parse_mode": parse_mode,
                "reply_markup": reply_markup,
            }
        )

        class Message:
            id = len(self.photos)

        return Message()

    async def send_message(self, chat_id, text, **kwargs):
        self.messages.append({"chat_id": str(chat_id), "text": text, **kwargs})
        return None


class _FakePillowResponse:
    def __init__(self, data, content_type, status=200, length=None):
        self._data = data
        self.status = status
        self.headers = _FakeHeaders(content_type, length)

    def read(self, size=-1):
        return self._data if size < 0 else self._data[:size]

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False


class _FakeHeaders:
    def __init__(self, content_type, length=None):
        self._content_type = content_type
        self._length = length

    def get_content_type(self):
        return self._content_type

    def get(self, key, default=None):
        if key == "Content-Length":
            return self._length
        return default


class PosterDeliveryTests(unittest.IsolatedAsyncioTestCase):
    def _delivery(self, poster=POSTER_URL, caption="Kongsi (2011)"):
        return {
            "chat_id": "-100111",
            "caption": caption,
            "poster": poster,
            "button_text": "GET NOW",
            "button_url": "https://t.me/examplegroup",
            "destination_type": "channel",
        }

    async def test_photo_send_does_not_pass_unsupported_kwargs(self):
        previous = engine._poster_usable
        engine._poster_usable = lambda poster: asyncio.sleep(0, result=True)
        try:
            bot = StrictPhotoBot()
            await engine._deliver(bot, self._delivery())
        finally:
            engine._poster_usable = previous
        self.assertEqual(len(bot.photos), 1)
        self.assertEqual(bot.messages, [])
        button = bot.photos[0]["reply_markup"].inline_keyboard[0][0]
        self.assertEqual(button.text, "GET NOW")
        self.assertEqual(button.url, "https://t.me/examplegroup")

    async def test_url_failure_retries_with_downloaded_image_bytes(self):
        previous_usable = engine._poster_usable
        previous_image = engine._poster_image

        async def usable(poster):
            return True

        async def image(poster):
            return PNG_BYTES, "poster.png", ""

        engine._poster_usable = usable
        engine._poster_image = image
        try:
            bot = StrictPhotoBot(reject_urls=True)
            await engine._deliver(bot, self._delivery())
        finally:
            engine._poster_usable = previous_usable
            engine._poster_image = previous_image
        self.assertEqual(len(bot.photos), 1)
        self.assertIsInstance(bot.photos[0]["photo"], io.BytesIO)
        self.assertEqual(bot.photos[0]["photo"].name, "poster.png")
        self.assertEqual(bot.messages, [])

    async def test_download_failure_still_delivers_text_with_button(self):
        previous_usable = engine._poster_usable
        previous_image = engine._poster_image

        async def usable(poster):
            return True

        async def image(poster):
            return b"", "", "poster HTTP 404"

        engine._poster_usable = usable
        engine._poster_image = image
        try:
            bot = StrictPhotoBot(reject_urls=True)
            await engine._deliver(bot, self._delivery())
        finally:
            engine._poster_usable = previous_usable
            engine._poster_image = previous_image
        self.assertEqual(bot.photos, [])
        self.assertEqual(len(bot.messages), 1)
        self.assertIsNotNone(bot.messages[0]["reply_markup"])
        self.assertTrue(bot.messages[0]["disable_web_page_preview"])

    def test_validate_accepts_real_png(self):
        usable, reason = imdb.validate_poster_bytes(PNG_BYTES, "image/png")
        self.assertTrue(usable, reason)

    def test_validate_rejects_html_body(self):
        usable, reason = imdb.validate_poster_bytes(b"<html>blocked</html>", "text/html")
        self.assertFalse(usable)
        self.assertIn("not an image", reason)

    def test_validate_rejects_html_mislabelled_as_image(self):
        usable, reason = imdb.validate_poster_bytes(b"<html>blocked</html>", "image/jpeg")
        self.assertFalse(usable)
        self.assertIn("not a supported image", reason)

    def test_validate_rejects_oversized_image(self):
        usable, reason = imdb.validate_poster_bytes(
            PNG_BYTES + b"\x00" * (imdb.MAX_POSTER_BYTES + 1), "image/png"
        )
        self.assertFalse(usable)
        self.assertIn("limit", reason)

    def test_fetch_downloads_and_validates_image(self):
        response = _FakePillowResponse(PNG_BYTES, "image/png", length=str(len(PNG_BYTES)))
        with mock.patch.object(imdb.urllib.request, "urlopen", return_value=response):
            data, filename, reason = imdb._fetch_poster_bytes_sync(POSTER_URL)
        self.assertEqual(reason, "")
        self.assertEqual(data, PNG_BYTES)
        self.assertEqual(filename, "poster.png")

    def test_fetch_follows_redirects_via_final_response(self):
        response = _FakePillowResponse(PNG_BYTES, "image/png")
        with mock.patch.object(imdb.urllib.request, "urlopen", return_value=response) as opener:
            data, _, reason = imdb._fetch_poster_bytes_sync(POSTER_URL)
        self.assertTrue(opener.called)
        self.assertEqual(reason, "")
        self.assertTrue(data)

    def test_fetch_rejects_html_error_page(self):
        response = _FakePillowResponse(b"<html>nope</html>", "text/html")
        with mock.patch.object(imdb.urllib.request, "urlopen", return_value=response):
            data, filename, reason = imdb._fetch_poster_bytes_sync(POSTER_URL)
        self.assertEqual(data, b"")
        self.assertEqual(filename, "")
        self.assertIn("not an image", reason)

    def test_fetch_rejects_missing_image(self):
        error = urllib.error.HTTPError(POSTER_URL, 404, "Not Found", {}, None)
        with mock.patch.object(imdb.urllib.request, "urlopen", side_effect=error):
            data, _, reason = imdb._fetch_poster_bytes_sync(POSTER_URL)
        self.assertEqual(data, b"")
        self.assertIn("404", reason)

    def test_convert_webp_to_jpeg_when_pillow_available(self):
        try:
            from PIL import Image
        except Exception:
            self.skipTest("Pillow not installed")
        buffer = io.BytesIO()
        Image.new("RGB", (8, 8), (20, 30, 40)).save(buffer, format="WEBP")
        prepared, filename = imdb._prepare_poster_bytes(buffer.getvalue())
        self.assertEqual(filename, "poster.jpg")
        usable, reason = imdb.validate_poster_bytes(prepared, "image/jpeg")
        self.assertTrue(usable, reason)

    async def test_fallback_poster_used_when_metadata_missing(self):
        settings = dict(engine.DEFAULT_SETTINGS)
        settings["fallback_poster"] = POSTER_URL
        payload = engine.build_payload(
            "evt", "movie", [movie_event()], {}, settings
        )
        self.assertEqual(payload["poster"], POSTER_URL)

    def test_event_poster_used_when_metadata_missing(self):
        event = movie_event()
        event["poster"] = POSTER_URL
        payload = engine.build_payload(
            "evt", "movie", [event], {}, dict(engine.DEFAULT_SETTINGS)
        )
        self.assertEqual(payload["poster"], POSTER_URL)

    def test_poster_disabled_setting_still_removes_poster(self):
        settings = dict(engine.DEFAULT_SETTINGS)
        settings["poster_enabled"] = False
        settings["fallback_poster"] = POSTER_URL
        payload = engine.build_payload("evt", "movie", [movie_event()], {}, settings)
        self.assertEqual(payload["poster"], "")


class StallingPhotoBot:
    """A bot whose photo upload never completes (simulates a network stall).

    This is the regression that stopped *all* notifications: the delivery
    worker awaited ``send_photo`` with no timeout, so one stalled upload
    blocked text delivery and the whole queue forever.
    """

    def __init__(self):
        self.photos = []
        self.messages = []
        self.username = "testbot"

    async def send_photo(
        self, chat_id, photo, caption="", parse_mode=None, reply_markup=None
    ):
        self.photos.append(photo)
        await asyncio.Event().wait()

    async def send_message(self, chat_id, text, **kwargs):
        self.messages.append({"chat_id": str(chat_id), "text": text, **kwargs})

        class Message:
            id = len(self.messages)

        return Message()


class DeliveryWatchdogTests(unittest.IsolatedAsyncioTestCase):
    def _delivery(self, poster=POSTER_URL):
        return {
            "chat_id": "-100111",
            "caption": "Kongsi (2011)",
            "poster": poster,
            "button_text": "GET NOW",
            "button_url": "https://t.me/examplegroup",
            "destination_type": "channel",
        }

    async def asyncSetUp(self):
        self.prev_poster_timeout = engine.POSTER_ATTEMPT_TIMEOUT
        self.prev_delivery_timeout = engine.DELIVERY_ATTEMPT_TIMEOUT
        engine.POSTER_ATTEMPT_TIMEOUT = 0.05

    async def asyncTearDown(self):
        engine.POSTER_ATTEMPT_TIMEOUT = self.prev_poster_timeout
        engine.DELIVERY_ATTEMPT_TIMEOUT = self.prev_delivery_timeout

    async def test_stalled_photo_upload_still_delivers_text(self):
        previous = engine._poster_usable

        async def usable(poster):
            return True

        engine._poster_usable = usable
        try:
            bot = StallingPhotoBot()
            delivery = self._delivery()
            await engine._deliver(bot, delivery)
        finally:
            engine._poster_usable = previous
        self.assertEqual(len(bot.messages), 1)
        self.assertIn("Kongsi (2011)", bot.messages[0]["text"])
        self.assertIsNotNone(bot.messages[0]["reply_markup"])
        self.assertTrue(bot.messages[0]["disable_web_page_preview"])
        self.assertEqual(delivery["poster_status"], "timeout")
        self.assertIn("timed out", delivery["poster_error"])

    async def test_stalled_bytes_upload_after_url_failure_still_delivers_text(self):
        class BytesStallingBot(StallingPhotoBot):
            async def send_photo(
                self, chat_id, photo, caption="", parse_mode=None, reply_markup=None
            ):
                if isinstance(photo, str):
                    raise ValueError("Telegram could not fetch the photo URL")
                self.photos.append(photo)
                await asyncio.Event().wait()

        previous_usable = engine._poster_usable
        previous_image = engine._poster_image

        async def usable(poster):
            return True

        async def image(poster):
            return PNG_BYTES, "poster.png", ""

        engine._poster_usable = usable
        engine._poster_image = image
        try:
            bot = BytesStallingBot()
            delivery = self._delivery()
            await engine._deliver(bot, delivery)
        finally:
            engine._poster_usable = previous_usable
            engine._poster_image = previous_image
        self.assertEqual(len(bot.messages), 1)
        self.assertEqual(delivery["poster_status"], "timeout")
        self.assertIn("Kongsi (2011)", bot.messages[0]["text"])

    async def test_stalled_poster_validation_still_delivers_text(self):
        previous = engine._poster_usable

        async def usable(poster):
            await asyncio.Event().wait()

        engine._poster_usable = usable
        try:
            bot = StallingPhotoBot()
            delivery = self._delivery()
            await engine._deliver(bot, delivery)
        finally:
            engine._poster_usable = previous
        self.assertEqual(len(bot.messages), 1)
        self.assertEqual(delivery["poster_status"], "timeout")

    async def test_download_failure_is_recorded_on_delivery(self):
        previous_usable = engine._poster_usable
        previous_image = engine._poster_image

        async def usable(poster):
            return True

        async def image(poster):
            return b"", "", "poster HTTP 404"

        engine._poster_usable = usable
        engine._poster_image = image
        try:
            bot = StrictPhotoBot(reject_urls=True)
            delivery = self._delivery()
            await engine._deliver(bot, delivery)
        finally:
            engine._poster_usable = previous_usable
            engine._poster_image = previous_image
        self.assertEqual(len(bot.messages), 1)
        self.assertEqual(delivery["poster_status"], "download_failed")
        self.assertIn("404", delivery["poster_error"])

    async def test_caption_too_long_records_status_and_sends_text(self):
        bot = StrictPhotoBot()
        delivery = self._delivery()
        delivery["caption"] = "x" * 1100
        await engine._deliver(bot, delivery)
        self.assertEqual(bot.photos, [])
        self.assertEqual(len(bot.messages), 1)
        self.assertEqual(delivery["poster_status"], "caption_too_long")

    async def test_timed_out_delivery_does_not_block_queue(self):
        db = FakeDatabase()
        previous_db = engine._db_handle
        previous_deliver = engine._deliver
        previous_settings = engine.get_settings
        engine.set_database(db)
        engine.DELIVERY_ATTEMPT_TIMEOUT = 0.05

        async def settings(force=False):
            return dict(engine.DEFAULT_SETTINGS)

        async def sometimes_stalls(bot, delivery):
            if delivery.get("poster") == "stall":
                await asyncio.Event().wait()

            class Message:
                id = 1

            return Message()

        engine.get_settings = settings
        engine._deliver = sometimes_stalls
        try:
            collection = db[engine.DELIVERIES_COLLECTION]
            base = {
                "status": "PENDING",
                "attempts": 0,
                "next_retry_at": engine._now(),
                "button_text": "GET NOW",
                "button_url": "https://t.me/examplegroup",
                "caption": "Kongsi (2011)",
            }
            await collection.insert_one(dict(base, delivery_id="d1", poster="stall"))
            await collection.insert_one(dict(base, delivery_id="d2", poster="ok"))
            sent = await engine.process_deliveries(FakeBot(), limit=2)
        finally:
            engine.set_database(previous_db)
            engine._deliver = previous_deliver
            engine.get_settings = previous_settings
        docs = {doc["delivery_id"]: doc for doc in collection.docs}
        self.assertEqual(docs["d2"]["status"], "SENT")
        self.assertEqual(docs["d1"]["status"], "RETRY_PENDING")
        self.assertIn("timed out", docs["d1"]["last_error"])
        self.assertEqual(docs["d2"]["last_error"], "")
        self.assertEqual(sent, 2)

    async def test_recovery_releases_processing_delivery(self):
        db = FakeDatabase()
        previous_db = engine._db_handle
        engine.set_database(db)
        try:
            await db[engine.DELIVERIES_COLLECTION].insert_one(
                {
                    "delivery_id": "d1",
                    "status": "PROCESSING",
                    "updated_at": engine._now() - engine.timedelta(hours=1),
                }
            )
            await engine.recover_pending_work(stale_minutes=0)
        finally:
            engine.set_database(previous_db)
        self.assertEqual(
            db[engine.DELIVERIES_COLLECTION].docs[0]["status"], "RETRY_PENDING"
        )

    async def test_worker_loop_survives_stalled_cycle(self):
        previous_once = engine.process_once
        previous_digest = engine.maybe_publish_weekly_digest
        previous_recover = engine.recover_pending_work
        previous_cycle = engine.WORKER_CYCLE_TIMEOUT
        previous_interval = engine.WORKER_INTERVAL
        calls = {"cycles": 0, "recover": None}

        async def stalled_once(bot):
            calls["cycles"] += 1
            await asyncio.Event().wait()

        async def recovery(stale_minutes=10):
            calls["recover"] = stale_minutes

        engine.process_once = stalled_once
        engine.maybe_publish_weekly_digest = lambda bot: asyncio.sleep(0)
        engine.recover_pending_work = recovery
        engine.WORKER_CYCLE_TIMEOUT = 0.05
        engine.WORKER_INTERVAL = 0
        try:
            task = asyncio.create_task(engine.notification_worker_loop(object()))
            await asyncio.sleep(0.2)
            task.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await task
        finally:
            engine.process_once = previous_once
            engine.maybe_publish_weekly_digest = previous_digest
            engine.recover_pending_work = previous_recover
            engine.WORKER_CYCLE_TIMEOUT = previous_cycle
            engine.WORKER_INTERVAL = previous_interval
        self.assertGreaterEqual(calls["cycles"], 2)
        self.assertEqual(calls["recover"], 0)

    async def test_search_provider_poster_is_reused(self):
        fake_utils = types.ModuleType("utils")

        async def get_poster(query, bulk=False, id=False, file=None):
            return {"poster": POSTER_URL}

        fake_utils.get_poster = get_poster
        previous = sys.modules.get("utils")
        sys.modules["utils"] = fake_utils
        try:
            poster = await engine._poster_from_search_provider(
                movie_event(), dict(engine.DEFAULT_SETTINGS)
            )
        finally:
            if previous is None:
                sys.modules.pop("utils", None)
            else:
                sys.modules["utils"] = previous
        self.assertEqual(poster, POSTER_URL)

    async def test_search_provider_failure_returns_no_poster(self):
        fake_utils = types.ModuleType("utils")

        async def get_poster(query, bulk=False, id=False, file=None):
            raise RuntimeError("provider down")

        fake_utils.get_poster = get_poster
        previous = sys.modules.get("utils")
        sys.modules["utils"] = fake_utils
        try:
            poster = await engine._poster_from_search_provider(
                movie_event(), dict(engine.DEFAULT_SETTINGS)
            )
        finally:
            if previous is None:
                sys.modules.pop("utils", None)
            else:
                sys.modules["utils"] = previous
        self.assertEqual(poster, "")

    async def test_poster_falls_back_to_search_provider(self):
        previous_pub = engine._lookup_public_imdb
        previous_legacy = engine._lookup_cinemagoer
        previous_poster = engine._poster_from_search_provider
        previous_db = engine._db_handle
        engine.set_database(FakeDatabase())

        async def public(event, settings):
            data = imdb.metadata_from_node(FULL_MOVIE_NODE)
            data.pop("poster", None)
            return data, ""

        async def legacy(event, settings):
            return {}, "skip"

        async def poster(event, settings):
            return POSTER_URL

        engine._lookup_public_imdb = public
        engine._lookup_cinemagoer = legacy
        engine._poster_from_search_provider = poster
        try:
            metadata = await engine.resolve_metadata(
                movie_event(), dict(engine.DEFAULT_SETTINGS)
            )
        finally:
            engine.set_database(previous_db)
            engine._lookup_public_imdb = previous_pub
            engine._lookup_cinemagoer = previous_legacy
            engine._poster_from_search_provider = previous_poster
        self.assertEqual(metadata["poster"], POSTER_URL)


if __name__ == "__main__":
    unittest.main()